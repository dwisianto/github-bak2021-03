brat-embedded-visualization-examples
====================================

minimal examples of brat annotation visualizations
