clear all;
close all;

dataset = 'MQ2008-agg';

%paths to data and this file - set these to the location where the folder
%is extracted
data_path = [pwd, filesep];
file_path = [pwd, filesep];

RESULTS = cell(5, 8);

for fold = 1:5

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%load data
load([data_path, dataset, filesep, 'Fold', num2str(fold), filesep, 'train.mat'], 'train_targets', 'train_data');
load([data_path, dataset, filesep, 'Fold', num2str(fold), filesep, 'vali.mat'], 'valid_targets', 'valid_data');
load([data_path, dataset, filesep, 'Fold', num2str(fold), filesep, 'test.mat'], 'test_targets', 'test_data');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%set the learning parameters
parameters.use_lambdarank = true;
parameters.init = 0.01;
parameters.maxiter = 200;
parameters.learning_cut_ndcg = 10;
parameters.svd_rank = 1;

%binary, rank difference and log rank difference methods to calculate the
%pairwse matrix Y
% parameters.normalize = false;
% parameters.pairwise_type = 'BINARY';
% parameters.learnrate = 0.01;

% parameters.normalize = true;
% parameters.pairwise_type = 'RANK DIFFERENCE';
% parameters.learnrate = 0.01;	

parameters.normalize = true;
parameters.pairwise_type = 'LOG RANK DIFFERENCE';
parameters.learnrate = 0.01;


parameters

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%compute SVD features for each query
train_data = extract_features_svd(train_data, parameters);
valid_data = extract_features_svd(valid_data, parameters);
test_data = extract_features_svd(test_data, parameters);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%find  1/DCG for every query
dcg = cell(size(train_targets, 1), 1);
for i = 1:size(train_targets, 1)

	nqdocs = size(train_targets{i, 1}, 1);
	dcg{i, 1} = zeros(1, nqdocs);

	sorted_targets = sort(train_targets{i, 1}, 1, 'descend');
	dcg{i, 1}(1, 1) = sorted_targets(1, 1);

	if dcg{i, 1}(1, 1) == 0 || nqdocs == 1
		continue
	end

	for j = 2:nqdocs
		dcg{i, 1}(1, j) = dcg{i, 1}(1, j-1) + (2^sorted_targets(j, 1) - 1) / log2(j + 1);
	end
	dcg{i, 1} = 1./dcg{i, 1};
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
E_TR = zeros(parameters.maxiter, 1);

NDCG_VL = zeros(parameters.maxiter, parameters.learning_cut_ndcg);
PR_VL = zeros(parameters.maxiter, parameters.learning_cut_ndcg+1);

NDCG_TS = zeros(parameters.maxiter, parameters.learning_cut_ndcg);
PR_TS = zeros(parameters.maxiter, parameters.learning_cut_ndcg+1);

NDCG_BEST = 0;
ITER_BEST = 0;
W_BEST = [];

%initialize weights
W = parameters.init .* randn(size(train_data{1, 1}, 2)+1, 1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
nqueries = size(train_targets, 1);
batch_perm = randperm(nqueries)';

for i = 1:parameters.maxiter
	startT = tic;
	for j = 1:nqueries
		if dcg{batch_perm(j, 1), 1}(1, 1) == 0
			continue
		end
		%compute gradients and update parameters
		[~, ~, RESULT_train] = ranknet_der(W,...
									train_data(batch_perm(j, 1), 1),...
									train_targets(batch_perm(j, 1), 1),...
									dcg(batch_perm(j, 1), 1),...
									parameters,...
									false);
		W = W - parameters.learnrate .* RESULT_train.df;
		E_TR(i, 1) = E_TR(i, 1) + RESULT_train.f;
	end

	%validation NDCG and MAP
	[~, ~, RESULT_valid] = ranknet_der(W, valid_data, [], [], parameters, true);
	[ndcg, precision, map] = evaluate_model(file_path, data_path, cell2mat(RESULT_valid.S_all), dataset, fold, 'vali');
	NDCG_VL(i, :) = ndcg;
	PR_VL(i, :) = [precision, map];

	%test NDCG and MAP
	[~, ~, RESULT_test] = ranknet_der(W, test_data, [], [], parameters, true);
	[ndcg, precision, map] = evaluate_model(file_path, data_path, cell2mat(RESULT_test.S_all), dataset, fold, 'test');
	NDCG_TS(i, :) = ndcg;
	PR_TS(i, :) = [precision, map];

	if NDCG_BEST <= NDCG_VL(i, end)
		NDCG_BEST = NDCG_VL(i, end);
		W_BEST = W;
		ITER_BEST = i;
	end
	
	fprintf(1, 'ITER:%4i   TIME:%2.2f   f:%6.2f   ITER BEST:%i\n', i, toc(startT), E_TR(i, 1), ITER_BEST);
	disp([NDCG_VL(i, :); NDCG_TS(i, :)])
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

RESULTS{fold, 1} = E_TR;
RESULTS{fold, 2} = PR_VL;
RESULTS{fold, 3} = NDCG_VL;
RESULTS{fold, 4} = PR_TS;
RESULTS{fold, 5} = NDCG_TS;
RESULTS{fold, 6} = parameters;
RESULTS{fold, 7} = ITER_BEST;
RESULTS{fold, 8} = W_BEST;

end

%average test results using validation NDCG@10
ndcg = [];
prec = [];
for fold = 1:5
	prec = [prec; RESULTS{fold, 4}(RESULTS{fold, 7}, :)];
	ndcg = [ndcg; RESULTS{fold, 5}(RESULTS{fold, 7}, :)];
end
fprintf(1, '%2.2f& ', 100.*mean(ndcg(:, 1:5), 1), 100.*mean(prec(:, 1:5), 1), 100.*mean(prec(:, end), 1));
fprintf(1, '\n');






