%RankNet and LambdaRank derivatives in checkgrad format
function [f, df, RESULT] = ranknet_der(W, data, targets, dcg, parameters, scores_only)

nqueries = size(data, 1);
ndims = size(data{1, 1}, 2);

%get the weights and the biases
cur = 0;
W1_single = reshape(W(cur+1:cur+ndims), ndims, 1);
cur = cur + ndims;
B1_single = reshape(W(cur+1:end), 1, 1);

dW1_single = zeros(ndims, 1);
dB1_single = zeros(1, 1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
f = 0;
df = [];
RESULT.f = f;
RESULT.df = df;
RESULT.S_all = cell(nqueries, 1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i = 1:size(data, 1)
	nqdocs = size(data{i, 1}, 1);
	qscores = data{i, 1} * W1_single + repmat(B1_single, nqdocs, 1);
	RESULT.S_all{i, 1} = qscores;

	if scores_only == true
		continue
	end

	qtargets = targets{i, 1};
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	[~, qranks] = sort(qscores, 'descend');
	[~, qranks] = sort(qranks, 'ascend');

	dfdscores = zeros(nqdocs, 1);
	for j = 1:nqdocs
		if qtargets(j, 1) == 0
			continue
		end

		for k = 1:nqdocs
			if qtargets(j, 1) <= qtargets(k, 1)
				continue
			end

			delta_ndcg = 1;
			if parameters.use_lambdarank == true
				%reweight pair by delta NDCG
				delta_ndcg =  (2^qtargets(j, 1) - 2^qtargets(k, 1)) *...
						(1/log2(1 + qranks(j, 1)) - 1/log2(1 + qranks(k, 1)));
				delta_ndcg = dcg{i, 1}(1, end) * abs(delta_ndcg);
			end
			lambda = delta_ndcg / (1 + exp(qscores(j, 1) - qscores(k, 1)));
			
			RESULT.f = RESULT.f + log(1 + exp(qscores(k, 1) - qscores(j, 1)));
			if lambda < 0
				keyboard
			end

			dfdscores(j, 1) = dfdscores(j, 1) - lambda;
			dfdscores(k, 1) = dfdscores(k, 1) + lambda;
		end
	end

	dW1_single = dW1_single + data{i, 1}' * dfdscores;
	dB1_single = dB1_single + sum(dfdscores, 1);

end

RESULT.df = [dW1_single(:); dB1_single(:)];
f = RESULT.f;
df = RESULT.df;

end