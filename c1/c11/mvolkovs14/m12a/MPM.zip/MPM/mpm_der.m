function [f, df, RESULT] = mpm_fixed_theta_der_LETOR4(scores, vars, thetas, data, parameters)
nqueries = size(data, 1);
nlists = size(thetas, 1);

f = 0;
df = [];

RESULT.f = 0;
RESULT.dfdS = cell(nqueries, 1);
RESULT.dfdV = cell(nqueries, 1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i = 1:nqueries
	query_scores = scores{i, 1};
	nqdocs = size(query_scores, 1);
	qdata = data{i, 1};

	dZdS = zeros(nlists, nqdocs);
	dQdS = zeros(nqdocs, 1);

	if parameters.use_vars == true
		query_vars = exp(vars{i, 1});
		dZdV = zeros(nlists, nqdocs);
		dQdV = zeros(nqdocs, 1);
	end

	%find partition function for each partial ranking list
	Z = zeros(nlists, 1);
	v_sum = 1;
	for j = 1:nqdocs
		for k = 1:nqdocs
			index1 = j;
			index2 = k;
			if index1 ~= index2
				s_diff = query_scores(index1, 1) - query_scores(index2, 1);
				if parameters.use_vars == true
					v_sum = query_vars(index1, 1) + query_vars(index2, 1);
				end
				e_diff = exp(s_diff .* thetas ./ v_sum);
				Z = Z + e_diff;

				temp = e_diff ./ v_sum;
				dZdS(:, index1) = dZdS(:, index1) + temp;
				dZdS(:, index2) = dZdS(:, index2) - temp;

				if parameters.use_vars == true
					dZdV(:, index1) = dZdV(:, index1) - (temp .* s_diff .* query_vars(index1, 1) ./ v_sum);
					dZdV(:, index2) = dZdV(:, index2) - (temp .* s_diff .* query_vars(index2, 1) ./ v_sum);
				end
			end
		end
	end
	dZdS = dZdS .* repmat(thetas ./ Z, 1, nqdocs);
	dZdS = dZdS';
	
	if parameters.use_vars == true
		dZdV = dZdV .* repmat(thetas ./ Z, 1, nqdocs);
		dZdV = dZdV';
	end

	%go over all rankings and find objective and gradients
	n_preferences = zeros(nlists, 1);
	v_sum = 1;
	for list_number = 1:size(qdata, 2)
		for j = 1:nqdocs-1
			for k = j+1:nqdocs
				list_theta = thetas(list_number, 1);

				%ranks for the pair
				r1 = qdata(j, list_number);
				r2 = qdata(k, list_number);

				if r1 == 0 || r2 == 0
					continue;
				end
				
				%scores for the pair
				s1 = query_scores(j, 1);
				s2 = query_scores(k, 1);

				%variance for the pair
				if parameters.use_vars == true
					v_sum = query_vars(j, 1) + query_vars(k, 1);
				end

				if r1 < r2
					diff_s = s1 - s2;
					diff_r = (r2 - r1);
					mult = 1;
				else
					diff_s = s2 - s1;
					diff_r = (r1 - r2);
					mult = -1;
				end

				if parameters.use_rank_difference == true
					n_preferences(list_number, 1) = n_preferences(list_number, 1) + diff_r;
					temp = list_theta * diff_r / v_sum;
				else
					n_preferences(list_number, 1) = n_preferences(list_number, 1) + 1;
					temp = list_theta / v_sum;
				end
				f = f + diff_s * temp;

				%derivatives
				dQdS(j, 1) = dQdS(j, 1) + mult * temp;
				dQdS(k, 1) = dQdS(k, 1) - mult * temp;
				if parameters.use_vars == true
					dQdV(j, 1) = dQdV(j, 1) - diff_s * temp * query_vars(j, 1) / v_sum;
					dQdV(k, 1) = dQdV(k, 1) - diff_s * temp * query_vars(k, 1) / v_sum;
				end
			end
		end
	end
	f = f - n_preferences' * log(Z);

	RESULT.dfdS{i, 1} = dQdS - dZdS * n_preferences;
	if parameters.use_vars == true
		RESULT.dfdV{i, 1} = dQdV - dZdV * n_preferences;
	end
end
RESULT.f = f;

end
