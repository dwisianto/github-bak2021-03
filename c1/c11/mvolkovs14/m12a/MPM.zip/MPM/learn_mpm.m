clear all;
close all;

%code directory
file_path = [pwd, filesep];
%data directory
data_path = [pwd, filesep];

RESULTS = cell(3, 1);
dataset = 'MQ2008-agg'

for fold = 1:5

load([data_path, dataset, filesep, 'Fold', num2str(fold), filesep, 'train.mat']);
load([data_path, dataset, filesep, 'Fold', num2str(fold), filesep, 'vali.mat']);
load([data_path, dataset, filesep, 'Fold', num2str(fold), filesep, 'test.mat']);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% for binary counts:
%  parameters.use_rank_difference = false;
%  parameters.learn_rate = 0.0005;

% for rank difference:
%  parameters.use_rank_difference = true;
%  parameters.learn_rate = 0.000005;

parameters.learn_rate = 0.000005;
parameters.maxiter = 100;
parameters.init = 0.001;
parameters.use_rank_difference = true;
parameters.use_vars = true; %learn variances gamma
parameters

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%initialize test scores and variances
nqueries = size(test_data, 1);
test_scores = cell(nqueries, 1);
test_vars = cell(nqueries, 1);
test_sizes = zeros(nqueries, 1);
for i = 1:nqueries
	nqdocs = size(test_data{i, 1}, 1);
	test_scores{i, 1} = parameters.init .* randn(nqdocs, 1);
	test_vars{i, 1} = parameters.init .* randn(nqdocs, 1);
	test_sizes(i, 1) = nqdocs;
end

%find thetas using labeled training queries
thetas = find_thetas_supervised(train_targets, train_data)';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
E_TS = zeros(parameters.maxiter, 1);
NDCG_TS = zeros(parameters.maxiter, 10);
PR_TS = zeros(parameters.maxiter, 10);
MAP_TS = zeros(parameters.maxiter, 1);

%fit scores and variances for each test query
startT = tic;
for i = 1:parameters.maxiter
	[~, ~, RESULT_test] = mpm_der(test_scores, test_vars, thetas, test_data, parameters);

	test_scores = cell2mat(test_scores) + parameters.learn_rate .* cell2mat(RESULT_test.dfdS);
	if parameters.use_vars == true
		test_vars = cell2mat(test_vars) + parameters.learn_rate .* cell2mat(RESULT_test.dfdV);
		test_vars = mat2cell(test_vars, test_sizes);
	end
	[NDCG_TS(i, :), PR_TS(i, :), MAP_TS(i, :)] = evaluate_model(file_path, data_path, test_scores, dataset, fold, 'test', '0');
	test_scores = mat2cell(test_scores, test_sizes);

	E_TS(i, 1) = RESULT_test.f;
	fprintf(1, 'ITER:%4i   f:%7.2f   |S|:%.2f\n', i, E_TS(i, 1), norm(cell2mat(test_scores), 2));
	disp(NDCG_TS(i, :))
end
toc(startT)

%evaluate the learned model
[ndcg, precision, map] = evaluate_model(file_path, data_path, cell2mat(test_scores), dataset, fold, 'test', '0');
RESULTS{1, 1} = [RESULTS{1, 1}; ndcg];
RESULTS{2, 1} = [RESULTS{2, 1}; precision];
RESULTS{3, 1} = [RESULTS{3, 1}; map];

end

%NDCG
mean(RESULTS{1})
%Precision
mean(RESULTS{2})
%MAP
mean(RESULTS{3})


%  MQ2008 TEST RESULTS: theta, vars, rank difference, 100 iters, learn_rate = 0.000005, init = 0.001
%  ans =
%      0.3817    0.4057    0.4219    0.4307    0.4399    0.4553    0.4672    0.4359    0.2068    0.2106
%  ans =
%      0.4489    0.4113    0.3767    0.3380    0.3115    0.2950    0.2833    0.2680    0.2484    0.2326
%  ans =
%      0.4471





















