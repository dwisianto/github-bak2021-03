function[correlation_means] = find_thetas_supervised(targets, data)

	nqueries = size(data, 1);
	nlists = size(data{1, 1}, 2);

	rank_correlation = zeros(nqueries, nlists);
	npairs = zeros(nqueries, 1);
	for i = 1:size(data, 1)
		[rank_correlation(i, :), npairs(i, 1)] = kendall_tau_rank_correlation(targets{i, 1}, data{i, 1}, nlists);
	end

	correlation_means = zeros(1, nlists);
	for i = 1:nlists
		%compute avergate Kendall's tau ignoring missing values
		correlation_means(1, i) = mean(rank_correlation(rank_correlation(:, i) ~= Inf, i), 1);
	end
	correlation_means(1, correlation_means(1, :) < 0) = 0;
end


function[rank_correlation, npairs] = kendall_tau_rank_correlation(targets, partial_rankings, nlists)

	nagree = zeros(1, nlists);
	ndisagree = zeros(1, nlists);
	npairs = 0;
	ndocs = size(targets, 1);

	for i = 1:ndocs - 1
		for j = i+1:ndocs
			if targets(i, 1) == targets(j, 1)
				continue
			end
			npairs = npairs + 1;

			if targets(i, 1) > targets(j, 1)
				for k = 1:nlists
					if partial_rankings(i, k) == 0 || partial_rankings(j, k) == 0
						continue
					end
	
					if partial_rankings(i, k) < partial_rankings(j, k)
						nagree(1, k) = nagree(1, k) + 1;
					else
						ndisagree(1, k) = ndisagree(1, k) + 1;
					end
				end
			else
				for k = 1:size(partial_rankings, 2)
					if partial_rankings(i, k) == 0 || partial_rankings(j, k) == 0
						continue
					end
	
					if partial_rankings(i, k) > partial_rankings(j, k)
						nagree(1, k) = nagree(1, k) + 1;
					else
						ndisagree(1, k) = ndisagree(1, k) + 1;
					end
				end
			end
		end
	end

	rank_correlation = inf(1, nlists);
	if npairs == 0
		return;
	end

	for i = 1:nlists
		if nagree(1, i) > 0 || ndisagree(1, i) > 0
			rank_correlation(1, i) = (nagree(1, i) - ndisagree(1, i)) ./ npairs;
		end
	end
end
