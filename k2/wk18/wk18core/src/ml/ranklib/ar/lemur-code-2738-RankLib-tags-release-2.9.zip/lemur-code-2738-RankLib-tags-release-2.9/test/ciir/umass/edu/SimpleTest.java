package ciir.umass.edu;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * @author jfoley.
 */
public class SimpleTest {

  @Test
  public void testSomething() {
    assertEquals(4, 4);
  }
}
