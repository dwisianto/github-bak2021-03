package ciir.umass.edu.stats;

import java.util.HashMap;

public class SignificanceTest {

	public double test(HashMap<String, Double> target, HashMap<String, Double> baseline)
	{
		return 0;
	}
	protected void makeRCall()
	{
		
	}
}
