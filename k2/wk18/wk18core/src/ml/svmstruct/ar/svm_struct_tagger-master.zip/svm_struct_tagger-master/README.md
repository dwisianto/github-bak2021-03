svm_struct_tagger
=================

Part-of-speech tagger based on Structured SVM with adaptive SGD solver

FST Structure for bigram tag features:

![FST Structure](https://dl.dropboxusercontent.com/u/1699417/other/struct_svm.png "FST Structure")
